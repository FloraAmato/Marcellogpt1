"""
evaluator.py
============
Compare the original sparse COLMAP point cloud with the densified result.

Metrics:
  1. Point count ratio (density gain)
  2. Coverage — how much of the original cloud is "covered" by the dense cloud
  3. Chamfer distance (mean nearest-neighbour distance, both directions)
  4. Precision / recall at a given distance threshold
  5. Bounding-box volume comparison
"""

import numpy as np
from typing import Dict, Optional
from scipy.spatial import cKDTree


def compute_metrics(
    sparse_xyz: np.ndarray,
    dense_xyz: np.ndarray,
    distance_threshold: float = 0.05,
    verbose: bool = True,
) -> Dict[str, float]:
    """
    Compute evaluation metrics between the original sparse cloud and the
    densified cloud.

    Parameters
    ----------
    sparse_xyz : (M, 3) — COLMAP points3D
    dense_xyz  : (N, 3) — densified RoMa v2 triangulated points
    distance_threshold : threshold (in world units) used for precision/recall.
                         Choose a reasonable value based on the scene scale.
    verbose : print a summary

    Returns
    -------
    Dictionary of metric names → values.
    """
    M = sparse_xyz.shape[0]
    N = dense_xyz.shape[0]

    results: Dict[str, float] = {}

    # ── 1. Density gain ───────────────────────
    results["sparse_count"] = M
    results["dense_count"] = N
    results["density_ratio"] = N / max(M, 1)

    # ── 2. Bounding-box volume ────────────────
    def bbox_volume(pts):
        lo, hi = pts.min(axis=0), pts.max(axis=0)
        return float(np.prod(hi - lo))

    results["sparse_bbox_volume"] = bbox_volume(sparse_xyz)
    results["dense_bbox_volume"] = bbox_volume(dense_xyz) if N > 0 else 0.0

    if N == 0:
        results["chamfer_sparse_to_dense"] = float("inf")
        results["chamfer_dense_to_sparse"] = float("inf")
        results["chamfer_symmetric"] = float("inf")
        results["coverage_recall"] = 0.0
        results["precision"] = 0.0
        if verbose:
            _print(results)
        return results

    # ── 3. KD-trees ───────────────────────────
    tree_sparse = cKDTree(sparse_xyz)
    tree_dense = cKDTree(dense_xyz)

    # Nearest-neighbour distances
    dist_s2d, _ = tree_dense.query(sparse_xyz)   # for each sparse pt, nn in dense
    dist_d2s, _ = tree_sparse.query(dense_xyz)    # for each dense pt, nn in sparse

    # ── 4. Chamfer distance ───────────────────
    results["chamfer_sparse_to_dense"] = float(dist_s2d.mean())
    results["chamfer_dense_to_sparse"] = float(dist_d2s.mean())
    results["chamfer_symmetric"] = (results["chamfer_sparse_to_dense"] +
                                     results["chamfer_dense_to_sparse"]) / 2

    # ── 5. Coverage (recall) ──────────────────
    #   "What fraction of sparse points have a dense neighbour within threshold?"
    results["coverage_recall"] = float((dist_s2d < distance_threshold).mean())

    # ── 6. Precision ──────────────────────────
    #   "What fraction of dense points are close to some sparse point?"
    results["precision"] = float((dist_d2s < distance_threshold).mean())

    # ── 7. Median & 90th percentile distances ─
    results["median_s2d"] = float(np.median(dist_s2d))
    results["p90_s2d"] = float(np.percentile(dist_s2d, 90))
    results["median_d2s"] = float(np.median(dist_d2s))
    results["p90_d2s"] = float(np.percentile(dist_d2s, 90))

    if verbose:
        _print(results)

    return results


def estimate_scene_scale(sparse_xyz: np.ndarray) -> float:
    """
    Heuristic: return the median pairwise distance among a subsample
    of sparse points.  Useful for choosing a sensible distance_threshold.
    """
    N = sparse_xyz.shape[0]
    if N < 3:
        return 1.0
    rng = np.random.default_rng(42)
    sample = sparse_xyz[rng.choice(N, min(N, 500), replace=False)]
    tree = cKDTree(sample)
    dists, _ = tree.query(sample, k=2)   # k=2 because k=1 is self
    return float(np.median(dists[:, 1]))


def _print(results: Dict[str, float]) -> None:
    print("\n" + "=" * 60)
    print("  EVALUATION — Sparse vs Dense Point Cloud")
    print("=" * 60)
    print(f"  Sparse points        : {results['sparse_count']:>12,.0f}")
    print(f"  Dense  points        : {results['dense_count']:>12,.0f}")
    print(f"  Density ratio (×)    : {results['density_ratio']:>12.2f}")
    print(f"  Sparse bbox volume   : {results['sparse_bbox_volume']:>12.4f}")
    print(f"  Dense  bbox volume   : {results['dense_bbox_volume']:>12.4f}")
    print(f"  Chamfer (sparse→dense): {results['chamfer_sparse_to_dense']:>11.6f}")
    print(f"  Chamfer (dense→sparse): {results['chamfer_dense_to_sparse']:>11.6f}")
    print(f"  Chamfer symmetric    : {results['chamfer_symmetric']:>12.6f}")
    print(f"  Coverage / recall    : {results['coverage_recall']:>12.4f}")
    print(f"  Precision            : {results['precision']:>12.4f}")
    if "median_s2d" in results:
        print(f"  Median sparse→dense  : {results['median_s2d']:>12.6f}")
        print(f"  P90    sparse→dense  : {results['p90_s2d']:>12.6f}")
        print(f"  Median dense→sparse  : {results['median_d2s']:>12.6f}")
        print(f"  P90    dense→sparse  : {results['p90_d2s']:>12.6f}")
    print("=" * 60 + "\n")
