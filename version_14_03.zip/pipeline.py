#!/usr/bin/env python3
"""
pipeline.py
===========
End-to-end pipeline:

  COLMAP triplet + images  ──▶  RoMa v2 dense matching  ──▶  dense .ply

Usage:
    python pipeline.py \
        --colmap_dir /path/to/colmap/sparse/0 \
        --images_dir /path/to/images \
        --output_ply dense_output.ply \
        --inspect_dir roma_inspection \
        [--top_k 20] \
        [--min_shared_points 50] \
        [--confidence_threshold 0.05] \
        [--max_reproj_error 2.0] \
        [--max_keypoints 50000] \
        [--distance_threshold_eval 0.05] \
        [--max_pairs 0] \
        [--no_inspect]
"""

import argparse
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image as PILImage

# Local modules
from colmap_parser import load_colmap_model, image_name_to_id
from pair_selector import get_top_pairs, unique_pairs_from_top_matches
from roma_matcher import RoMaV2Matcher, DenseMatchResult
from roma_inspector import (
    compute_pair_metrics,
    generate_pair_artifacts,
    generate_aggregate_report,
)
from triangulator import (
    triangulate_dlt_batched,
    filter_by_reprojection,
    filter_by_cheirality,
    colorize_from_image,
)
from ply_io import write_ply, colmap_points3d_to_ply
from evaluator import compute_metrics, estimate_scene_scale


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def resolve_image_path(images_dir: Path, image_name: str) -> Path:
    """Try common sub-structures: flat, images/, etc."""
    candidates = [
        images_dir / image_name,
        images_dir / "images" / image_name,
    ]
    for c in candidates:
        if c.exists():
            return c
    raise FileNotFoundError(
        f"Cannot find image '{image_name}' in {images_dir}. "
        f"Tried: {[str(c) for c in candidates]}"
    )


def _slug(name: str) -> str:
    return Path(name).stem.replace(" ", "_").replace("/", "_")


# ──────────────────────────────────────────────
# Main pipeline
# ──────────────────────────────────────────────

def run_pipeline(args):
    t0 = time.time()
    do_inspect = not args.no_inspect
    inspect_dir = Path(args.inspect_dir) if do_inspect else None

    # ── 1. Load COLMAP model ──────────────────
    print("\n[1/6] Loading COLMAP model …")
    cameras, images, points3d = load_colmap_model(args.colmap_dir)
    name2id = image_name_to_id(images)
    print(f"       {len(cameras)} cameras, {len(images)} images, "
          f"{len(points3d)} 3D points")

    # ── 2. Select pairs ──────────────────────
    print("\n[2/6] Selecting best pairs by covisibility …")
    top_matches = get_top_pairs(images, top_k=args.top_k)
    pairs = unique_pairs_from_top_matches(
        top_matches, min_shared_points=args.min_shared_points
    )
    print(f"       {len(pairs)} unique pairs above threshold")
    if args.max_pairs > 0 and len(pairs) > args.max_pairs:
        pair_scores = {}
        for nameA, nameB in pairs:
            for m in top_matches.get(nameA, []):
                if m["matched_image"] == nameB:
                    pair_scores[(nameA, nameB)] = m["shared_3d_points"]
                    break
        pairs = sorted(pairs, key=lambda p: pair_scores.get(p, 0), reverse=True)[
            : args.max_pairs
        ]
        print(f"       Capped to {len(pairs)} pairs (--max_pairs)")

    # ── 3. Initialize matcher ────────────────
    print("\n[3/6] Initializing RoMa v2 matcher …")
    matcher = RoMaV2Matcher(
        device="cuda",
        confidence_threshold=args.confidence_threshold,
        max_keypoints=args.max_keypoints,
    )

    # ── 4. Match + inspect + triangulate ─────
    print(f"\n[4/6] Dense matching & triangulation for {len(pairs)} pairs …")
    if do_inspect:
        print(f"       Inspection artifacts → {inspect_dir}/")
        inspect_dir.mkdir(parents=True, exist_ok=True)

    all_xyz = []
    all_rgb = []
    all_pair_metrics = []
    images_dir = Path(args.images_dir)

    for idx, (nameA, nameB) in enumerate(pairs, 1):
        print(f"  [{idx}/{len(pairs)}] {nameA} ↔ {nameB}", end=" … ")

        # Resolve paths
        try:
            pathA = resolve_image_path(images_dir, nameA)
            pathB = resolve_image_path(images_dir, nameB)
        except FileNotFoundError as e:
            print(f"SKIP ({e})")
            continue

        # COLMAP data
        idA, idB = name2id[nameA], name2id[nameB]
        imgA, imgB_colmap = images[idA], images[idB]
        KA = cameras[imgA.camera_id].intrinsic_matrix()
        KB = cameras[imgB_colmap.camera_id].intrinsic_matrix()
        PA = imgA.projection_matrix(KA)
        PB = imgB_colmap.projection_matrix(KB)

        # ── Dense matching ──
        result: DenseMatchResult = matcher.match_pair(
            str(pathA), str(pathB),
            image_name_A=nameA,
            image_name_B=nameB,
        )

        # ── Per-pair metrics ──
        pair_metrics = compute_pair_metrics(result)

        # ── Per-pair artifacts ──
        if do_inspect:
            pair_slug = f"{_slug(nameA)}__{_slug(nameB)}"
            pair_artifact_dir = str(inspect_dir / "pairs" / pair_slug)
            generate_pair_artifacts(
                result,
                image_path_A=str(pathA),
                image_path_B=str(pathB),
                out_dir=pair_artifact_dir,
                pair_metrics=pair_metrics,
            )

        all_pair_metrics.append(pair_metrics)

        n_raw = result.kpts_A.shape[0]
        if n_raw == 0:
            print(f"0 matches → skip triangulation")
            continue

        # ── Triangulate ──
        pts_3d = triangulate_dlt_batched(PA, PB, result.kpts_A, result.kpts_B)

        # Cheirality
        che_mask = filter_by_cheirality(PA, PB, pts_3d)
        pts_3d = pts_3d[che_mask]
        kpts_A = result.kpts_A[che_mask]
        kpts_B = result.kpts_B[che_mask]

        if pts_3d.shape[0] == 0:
            print(f"{n_raw} matches, 0 after cheirality → skip")
            continue

        # Reprojection filter
        _, _, pts_3d, reproj_mask = filter_by_reprojection(
            PA, PB, kpts_A, kpts_B, pts_3d,
            max_reproj_error=args.max_reproj_error,
        )
        kpts_A_filt = kpts_A[reproj_mask]

        if pts_3d.shape[0] == 0:
            print(f"{n_raw} matches, 0 after reproj filter → skip")
            continue

        # Colorize
        imgA_np = np.array(PILImage.open(str(pathA)).convert("RGB"))
        colors = colorize_from_image(imgA_np, kpts_A_filt)

        all_xyz.append(pts_3d)
        all_rgb.append(colors)

        print(f"{n_raw} raw → {pts_3d.shape[0]} valid 3D pts "
              f"(conf={pair_metrics.get('conf_mean',0):.3f}, "
              f"t={pair_metrics.get('total_time_s',0):.2f}s)")

    # ── 4b. Aggregate inspection report ──────
    if do_inspect and all_pair_metrics:
        print(f"\n       Generating aggregate report …")
        agg_files = generate_aggregate_report(all_pair_metrics, str(inspect_dir))
        for name, path in agg_files.items():
            print(f"         {name}: {path}")

    # ── 5. Assemble & export ─────────────────
    print("\n[5/6] Assembling dense point cloud …")
    if not all_xyz:
        print("  ⚠  No points were triangulated.  Exiting.")
        sys.exit(1)

    dense_xyz = np.vstack(all_xyz)
    dense_rgb = np.vstack(all_rgb)
    print(f"       Total dense points: {dense_xyz.shape[0]:,}")

    dense_xyz, dense_rgb = _deduplicate(dense_xyz, dense_rgb, eps=1e-5)
    print(f"       After dedup:        {dense_xyz.shape[0]:,}")

    output_path = Path(args.output_ply)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    write_ply(str(output_path), dense_xyz, dense_rgb)

    sparse_ply = output_path.with_name("sparse_colmap.ply")
    sparse_xyz, sparse_rgb = colmap_points3d_to_ply(points3d, str(sparse_ply))

    # ── 6. Evaluate ──────────────────────────
    print("\n[6/6] Evaluating dense vs sparse …")
    scale = estimate_scene_scale(sparse_xyz)
    dist_thresh = args.distance_threshold_eval if args.distance_threshold_eval > 0 else scale * 0.02
    print(f"       Scene scale ≈ {scale:.4f}, distance threshold = {dist_thresh:.6f}")

    metrics = compute_metrics(
        sparse_xyz, dense_xyz,
        distance_threshold=dist_thresh,
        verbose=True,
    )

    elapsed = time.time() - t0
    print(f"\nDone in {elapsed:.1f} s.")
    print(f"  PLY output  : {output_path}")
    if do_inspect:
        print(f"  Inspection  : {inspect_dir}/")
        print(f"  Dashboard   : {inspect_dir}/roma_dashboard.html")
    return metrics


# ──────────────────────────────────────────────
# Deduplication
# ──────────────────────────────────────────────

def _deduplicate(xyz, rgb, eps=1e-5):
    if xyz.shape[0] == 0:
        return xyz, rgb
    voxel = np.round(xyz / eps).astype(np.int64)
    _, unique_idx = np.unique(voxel, axis=0, return_index=True)
    return xyz[unique_idx], rgb[unique_idx]


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="COLMAP → RoMa v2 dense matching → dense PLY"
    )
    p.add_argument("--colmap_dir", required=True,
                   help="Path to COLMAP text model dir")
    p.add_argument("--images_dir", required=True,
                   help="Path to the image directory")
    p.add_argument("--output_ply", default="dense_output.ply",
                   help="Output .ply file path")

    # Inspection
    p.add_argument("--inspect_dir", default="roma_inspection",
                   help="Directory for all RoMa v2 inspection artifacts")
    p.add_argument("--no_inspect", action="store_true",
                   help="Disable artifact generation (faster, less disk)")

    # Matching params
    p.add_argument("--top_k", type=int, default=20)
    p.add_argument("--min_shared_points", type=int, default=50)
    p.add_argument("--confidence_threshold", type=float, default=0.05)
    p.add_argument("--max_reproj_error", type=float, default=2.0)
    p.add_argument("--max_keypoints", type=int, default=50_000)
    p.add_argument("--max_pairs", type=int, default=0)
    p.add_argument("--distance_threshold_eval", type=float, default=0.0)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_pipeline(args)
