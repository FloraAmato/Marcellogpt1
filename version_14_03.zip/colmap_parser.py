"""
colmap_parser.py
================
Robust parser for COLMAP text-format reconstruction files:
  - cameras.txt
  - images.txt
  - points3D.txt

All loaders are streaming (line-by-line) so they work on large files.
"""

import numpy as np
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ──────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────

@dataclass
class Camera:
    """Intrinsic camera model."""
    camera_id: int
    model: str
    width: int
    height: int
    params: np.ndarray          # focal, cx, cy, distortion coeffs …

    # convenience ─────────────────
    def intrinsic_matrix(self) -> np.ndarray:
        """Return 3×3 K matrix.  Supports SIMPLE_PINHOLE, PINHOLE,
        SIMPLE_RADIAL, RADIAL, OPENCV, FULL_OPENCV."""
        if self.model in ("SIMPLE_PINHOLE", "SIMPLE_RADIAL"):
            f = self.params[0]
            cx, cy = self.params[1], self.params[2]
            return np.array([[f, 0, cx],
                             [0, f, cy],
                             [0, 0,  1]], dtype=np.float64)
        elif self.model in ("PINHOLE", "RADIAL", "OPENCV", "FULL_OPENCV"):
            fx, fy = self.params[0], self.params[1]
            cx, cy = self.params[2], self.params[3]
            return np.array([[fx,  0, cx],
                             [ 0, fy, cy],
                             [ 0,  0,  1]], dtype=np.float64)
        else:
            raise ValueError(f"Unsupported camera model: {self.model}")


@dataclass
class Image:
    """Extrinsic pose + 2D observations for one image."""
    image_id: int
    qvec: np.ndarray            # quaternion (w, x, y, z)
    tvec: np.ndarray            # translation
    camera_id: int
    name: str
    point2d_xy: np.ndarray      # (N, 2)  pixel coords
    point3d_ids: np.ndarray     # (N,)    -1 for unmatched

    # convenience ─────────────────
    def rotation_matrix(self) -> np.ndarray:
        """Quaternion → 3×3 rotation matrix (COLMAP convention)."""
        w, x, y, z = self.qvec
        return np.array([
            [1 - 2*y*y - 2*z*z,     2*x*y - 2*w*z,     2*x*z + 2*w*y],
            [    2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z,     2*y*z - 2*w*x],
            [    2*x*z - 2*w*y,     2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y],
        ], dtype=np.float64)

    def projection_matrix(self, K: np.ndarray) -> np.ndarray:
        """Return 3×4 projection matrix  P = K [R | t]."""
        R = self.rotation_matrix()
        Rt = np.hstack([R, self.tvec.reshape(3, 1)])
        return K @ Rt

    def camera_center(self) -> np.ndarray:
        """World-space camera centre  C = -R^T t."""
        R = self.rotation_matrix()
        return -R.T @ self.tvec


@dataclass
class Point3D:
    """One reconstructed 3D point."""
    point3d_id: int
    xyz: np.ndarray             # (3,)
    rgb: np.ndarray             # (3,) uint8
    error: float
    image_ids: np.ndarray       # images that observe this point
    point2d_idxs: np.ndarray    # index into each image's point2d list


# ──────────────────────────────────────────────
# Loaders
# ──────────────────────────────────────────────

def load_cameras(path: str) -> Dict[int, Camera]:
    """Parse cameras.txt → {camera_id: Camera}."""
    cameras: Dict[int, Camera] = {}
    with open(path, "r") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split()
            cam_id = int(parts[0])
            model = parts[1]
            width = int(parts[2])
            height = int(parts[3])
            params = np.array([float(p) for p in parts[4:]], dtype=np.float64)
            cameras[cam_id] = Camera(cam_id, model, width, height, params)
    return cameras


def load_images(path: str) -> Dict[int, Image]:
    """Parse images.txt → {image_id: Image}."""
    images: Dict[int, Image] = {}
    with open(path, "r") as f:
        entry_line = 0
        header_parts = None
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split()
            if entry_line % 2 == 0:
                header_parts = parts
            else:
                # Parse 2D points
                n_points = len(parts) // 3
                xy = np.empty((n_points, 2), dtype=np.float64)
                ids = np.empty(n_points, dtype=np.int64)
                for i in range(n_points):
                    xy[i, 0] = float(parts[3 * i])
                    xy[i, 1] = float(parts[3 * i + 1])
                    ids[i] = int(parts[3 * i + 2])

                img_id = int(header_parts[0])
                qvec = np.array([float(header_parts[j]) for j in range(1, 5)])
                tvec = np.array([float(header_parts[j]) for j in range(5, 8)])
                cam_id = int(header_parts[8])
                name = header_parts[9]
                images[img_id] = Image(img_id, qvec, tvec, cam_id, name, xy, ids)
            entry_line += 1
    return images


def load_points3d(path: str) -> Dict[int, Point3D]:
    """Parse points3D.txt → {point3d_id: Point3D}."""
    points: Dict[int, Point3D] = {}
    with open(path, "r") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.strip().split()
            pid = int(parts[0])
            xyz = np.array([float(parts[1]), float(parts[2]), float(parts[3])])
            rgb = np.array([int(parts[4]), int(parts[5]), int(parts[6])], dtype=np.uint8)
            error = float(parts[7])
            track_len = (len(parts) - 8) // 2
            img_ids = np.array([int(parts[8 + 2 * i]) for i in range(track_len)], dtype=np.int64)
            pt_idxs = np.array([int(parts[9 + 2 * i]) for i in range(track_len)], dtype=np.int64)
            points[pid] = Point3D(pid, xyz, rgb, error, img_ids, pt_idxs)
    return points


# ──────────────────────────────────────────────
# Convenience: load everything at once
# ──────────────────────────────────────────────

def load_colmap_model(model_dir: str):
    """Load a full COLMAP text model directory.

    Returns (cameras, images, points3d) dictionaries.
    """
    model_dir = Path(model_dir)
    cameras = load_cameras(str(model_dir / "cameras.txt"))
    images = load_images(str(model_dir / "images.txt"))
    points3d = load_points3d(str(model_dir / "points3D.txt"))
    return cameras, images, points3d


def image_name_to_id(images: Dict[int, Image]) -> Dict[str, int]:
    """Build reverse mapping  image_name → image_id."""
    return {img.name: img.image_id for img in images.values()}
