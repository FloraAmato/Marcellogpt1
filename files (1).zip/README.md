# COLMAP → RoMa v2 → Dense PLY Pipeline

Pipeline che densifica una ricostruzione COLMAP sparsa utilizzando il dense matcher **RoMa v2** (Edstedt et al., 2025) per triangolare una nuvola di punti molto più densa.

## Architettura della Pipeline

```
┌─────────────────┐
│  COLMAP triplet  │  cameras.txt / images.txt / points3D.txt
│  + immagini      │
└────────┬────────┘
         │
    ① Pair Selection (covisibilità)
         │    → top_k coppie per immagine, filtrate per min_shared_points
         │
    ② Dense Matching (RoMa v2)
         │    → per ogni coppia: warp W^{A→B}, confidence p^{A→B}
         │    → pixel matches filtrati per soglia di confidenza
         │
    ③ Triangolazione (DLT)
         │    → K, [R|t] da COLMAP → matrici P (3×4)
         │    → per ogni match: triangolazione lineare
         │    → filtro cheiralità (punti davanti a entrambe le camere)
         │    → filtro errore di riproiezione
         │    → colorizzazione da immagine sorgente
         │
    ④ Assemblaggio e Deduplicazione
         │    → unione punti da tutte le coppie
         │    → dedup con voxel grid
         │
    ⑤ Export PLY
         │
    ⑥ Valutazione
         │    → confronto sparse vs dense:
         │       Chamfer distance, coverage, precision, density ratio
         │
┌────────┴────────┐
│  dense_output.ply │
│  sparse_colmap.ply│
│  metriche         │
└─────────────────┘
```

## Prerequisiti

```bash
# PyTorch con supporto CUDA (vedi https://pytorch.org)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

# Dipendenze Python
pip install numpy scipy Pillow

# Opzionale (per lettura PLY binari)
pip install open3d
```

> **Nota**: RoMa v2 viene caricato automaticamente via `torch.hub` dal repo ufficiale
> [`Parskatt/romav2`](https://github.com/Parskatt/romav2). Non serve installazione manuale.
> Se il download fallisce, il sistema tenta il fallback a RoMa v1.

## Utilizzo

```bash
python pipeline.py \
    --colmap_dir /path/to/sparse/0 \
    --images_dir /path/to/images \
    --output_ply results/dense_output.ply \
    --top_k 20 \
    --min_shared_points 50 \
    --confidence_threshold 0.05 \
    --max_reproj_error 2.0 \
    --max_keypoints 50000 \
    --max_pairs 100
```

### Parametri principali

| Parametro | Default | Descrizione |
|-----------|---------|-------------|
| `--colmap_dir` | *required* | Directory con `cameras.txt`, `images.txt`, `points3D.txt` |
| `--images_dir` | *required* | Directory con le immagini originali |
| `--output_ply` | `dense_output.ply` | File PLY di output |
| `--top_k` | 20 | Numero massimo di partner per immagine |
| `--min_shared_points` | 50 | Soglia minima di punti 3D condivisi |
| `--confidence_threshold` | 0.05 | Soglia di confidenza RoMa v2 |
| `--max_reproj_error` | 2.0 | Errore di riproiezione max (pixel) |
| `--max_keypoints` | 50000 | Max corrispondenze dense per coppia |
| `--max_pairs` | 0 (tutti) | Limite coppie processate |
| `--distance_threshold_eval` | 0 (auto) | Soglia per precision/recall (0 = auto dalla scala scena) |

## Struttura dei File

```
colmap_to_dense_ply/
├── pipeline.py          # Orchestratore principale
├── colmap_parser.py     # Parser COLMAP text files
├── pair_selector.py     # Selezione coppie per covisibilità
├── roma_matcher.py      # Wrapper RoMa v2 (torch.hub)
├── triangulator.py      # DLT triangulation + filtri
├── ply_io.py            # Lettura/scrittura PLY
├── evaluator.py         # Metriche sparse vs dense
├── requirements.txt
└── README.md
```

## Metriche di Valutazione

L'evaluator confronta la nuvola sparsa COLMAP con il risultato denso:

- **Density ratio** — rapporto N_dense / N_sparse
- **Chamfer distance** — media della distanza nearest-neighbour bidirezionale
- **Coverage (recall)** — percentuale di punti sparsi "coperti" da un punto denso entro threshold
- **Precision** — percentuale di punti densi vicini ad almeno un punto sparso
- **P50 / P90** — mediana e 90° percentile delle distanze

## Note sulla Covarianza Predittiva (opzionale)

RoMa v2 predice una matrice di precisione 2×2 per pixel (Σ⁻¹) che esprime
l'incertezza attesa del match. Questo può essere utilizzato per:

1. **Pesare i residui** durante la triangolazione (DLT pesato / IRLS)
2. **Reweighting in RANSAC** per migliorare la stima di pose
3. **Filtraggio adattivo** — scartare punti con alta incertezza predetta

L'implementazione corrente usa la confidenza scalare per il filtraggio.
Per sfruttare la covarianza completa, si può estendere `roma_matcher.py`
per estrarre anche `Σ⁻¹` dal modello.

## Riferimenti

- **RoMa v2**: Edstedt et al., *RoMa v2: Harder Better Faster Denser Feature Matching*, arXiv:2511.15706, 2025
- **COLMAP**: Schönberger & Frahm, *Structure-from-Motion Revisited*, CVPR 2016
