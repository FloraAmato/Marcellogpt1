# COLMAP → RoMa v2 → Dense PLY Pipeline

Pipeline che densifica una ricostruzione COLMAP sparsa utilizzando il dense matcher **RoMa v2** (Edstedt et al., 2025) e produce un output **completamente ispezionabile**: per ogni coppia processata vengono generati artefatti visivi, metriche numeriche, e un report aggregato con dashboard HTML.

---

## Architettura della Pipeline

```
┌─────────────────┐
│  COLMAP triplet  │  cameras.txt / images.txt / points3D.txt
│  + immagini      │
└────────┬────────┘
         │
    ① Pair Selection (covisibilità da punti 3D condivisi)
         │
    ② Dense Matching (RoMa v2)
         │    ┌──────────────────────────────────────────────────┐
         │    │  PER-PAIR INSPECTION (roma_inspector.py)         │
         │    │  • confidence_heatmap.png                        │
         │    │  • warp_colormap.png                             │
         │    │  • match_lines.png                               │
         │    │  • confidence_histogram.png                      │
         │    │  • spatial_distribution.png                      │
         │    │  • pair_metrics.json                             │
         │    └──────────────────────────────────────────────────┘
         │
    ③ Triangolazione DLT + filtri (cheiralità, riproiezione)
         │
    ④ Assemblaggio, deduplicazione, export PLY
         │
    ⑤ Valutazione (Chamfer distance, coverage, precision)
         │
         │    ┌──────────────────────────────────────────────────┐
         │    │  REPORT AGGREGATO                                │
         │    │  • roma_pairs_report.csv                         │
         │    │  • roma_summary.json                             │
         │    │  • global_confidence_histogram.png               │
         │    │  • roma_dashboard.html                           │
         │    └──────────────────────────────────────────────────┘
         │
┌────────┴────────┐
│  dense_output.ply │
│  sparse_colmap.ply│
└─────────────────┘
```

---

## Utilizzo rapido

```bash
python pipeline.py \
    --colmap_dir /path/to/sparse/0 \
    --images_dir /path/to/images \
    --output_ply results/dense_output.ply \
    --inspect_dir results/roma_inspection \
    --max_pairs 100
```

Per disabilitare la generazione degli artefatti (più veloce, meno disco):

```bash
python pipeline.py ... --no_inspect
```

---

## Struttura dell'output di ispezione

```
roma_inspection/
├── roma_dashboard.html               ← Dashboard interattiva
├── roma_summary.json                 ← Statistiche aggregate
├── roma_pairs_report.csv             ← Tabella CSV di tutte le coppie
├── global_confidence_histogram.png   ← Istogrammi globali
└── pairs/
    ├── IMG_001__IMG_002/
    │   ├── confidence_heatmap.png
    │   ├── warp_colormap.png
    │   ├── match_lines.png
    │   ├── confidence_histogram.png
    │   ├── spatial_distribution.png
    │   └── pair_metrics.json
    ├── IMG_001__IMG_003/
    │   └── ...
    └── ...
```

---

## Artefatti visivi per coppia — Significato dettagliato

### 1. `confidence_heatmap.png` — Mappa di confidenza

**Cosa mostra**: l'immagine A con sovrapposta una heatmap semi-trasparente che rappresenta la confidenza predetta da RoMa v2 per ogni pixel. Usa la colourmap "inferno" (nero = 0, giallo = 1) con barra colorimetrica.

**Come si legge**: le zone giallo/arancione sono i pixel per i quali RoMa v2 è sicuro di aver trovato una corrispondenza valida nell'immagine B. Le zone scure indicano pixel per cui il matcher non ha trovato corrispondenze affidabili — tipicamente zone occluse, fuori campo, o con texture ambigua.

**A cosa serve**: permette di capire *dove* il matching è riuscito e dove no. Zone dell'immagine con bassa confidenza sono candidate naturali per problemi di triangolazione. Se ampie porzioni della scena risultano scure, potrebbe significare che la coppia ha troppo poca sovrapposizione o che la scena in quei punti presenta sfide (superfici speculari, cielo, regioni senza texture).

---

### 2. `warp_colormap.png` — Trasferimento colore via warp

**Cosa mostra**: per ogni pixel nella griglia del warp di immagine A, campiona il colore RGB dalla posizione corrispondente in immagine B. La luminosità è modulata dalla confidenza: alta confidenza → colori pieni; bassa confidenza → pixel attenuati/scuri.

**Come si legge**: se il matching è perfetto, quest'immagine dovrebbe sembrare una versione "riallineata" dell'immagine B vista dal punto di vista dell'immagine A. Artefatti come colori distorti, bande colorate, o zone sbiadite indicano warp errati o zone senza corrispondenza. Questa è la stessa visualizzazione usata nel paper RoMa v2 (Figura 2).

**A cosa serve**: ispezione qualitativa rapida della qualità del warp denso. Un warp pulito produce un'immagine coerente; un warp rumoroso produce artefatti caotici. È il modo più intuitivo per valutare se il matcher sta "capendo" la geometria della scena.

---

### 3. `match_lines.png` — Linee di corrispondenza

**Cosa mostra**: immagine A e immagine B affiancate, con un campione di fino a 300 corrispondenze visualizzate come linee colorate (rosso = bassa confidenza, verde = alta confidenza). Il campionamento è pesato per confidenza (i match migliori hanno più probabilità di essere mostrati).

**Come si legge**: linee parallele e coerenti nella stessa regione indicano matching geometricamente consistente. Linee che "saltano" in modo casuale indicano match errati (outlier). Il colore permette di distinguere immediatamente le corrispondenze affidabili da quelle dubbie.

**A cosa serve**: è la diagnostica classica per valutare se il matcher sta producendo corrispondenze sensate. Particolarmente utile per individuare failure mode (es. matching errato di strutture ripetitive, confusione tra oggetti simili).

---

### 4. `confidence_histogram.png` — Istogramma di confidenza

**Cosa mostra**: distribuzione delle confidenze di tutti i match filtrati per questa coppia. Include linee verticali per la mediana (P50), il 90° percentile (P90) e il 95° (P95).

**Come si legge**: una distribuzione spostata a destra (verso 1.0) indica match generalmente affidabili. Una distribuzione bimodale (picco vicino a 0 e picco vicino a 1) è tipica di scene con chiara separazione tra zone covisibili e non. Una distribuzione piatta o spostata a sinistra indica matching difficile.

**A cosa serve**: permette di calibrare la soglia `--confidence_threshold`. Se la maggior parte dei match ha confidenza sotto 0.2, forse la coppia è troppo difficile. Se la distribuzione è molto concentrata sopra 0.8, si può alzare la soglia per ottenere match ancora più puliti.

---

### 5. `spatial_distribution.png` — Distribuzione spaziale dei match

**Cosa mostra**: scatter plot di tutti i keypoint nell'immagine A (sottocampionati a 5000 per leggibilità), colorati secondo la loro confidenza (colourmap "plasma": viola = bassa, giallo = alta).

**Come si legge**: la distribuzione dovrebbe idealmente coprire tutta la regione covisibile tra le due immagini. Cluster isolati indicano zone locali di buon matching; grandi vuoti indicano zone dove il matching è fallito. La colorazione permette di vedere se le zone più confidenti sono concentrate in un'area (es. vicino al centro, dove tipicamente c'è più overlap) o distribuite uniformemente.

**A cosa serve**: diagnostica spaziale. Se tutti i match sono concentrati in un angolo, la coppia probabilmente ha overlap solo parziale. Se i match ad alta confidenza seguono linee specifiche, potrebbe indicare che il matcher sta sfruttando bordi strutturali forti.

---

### 6. `pair_metrics.json` — Metriche numeriche per coppia

File JSON con tutte le metriche computate. Campi:

---

## Metriche numeriche per coppia — Dizionario completo

| Metrica | Tipo | Significato |
|---------|------|-------------|
| `image_A`, `image_B` | string | Nomi delle due immagini della coppia |
| `total_warp_pixels` | int | Numero totale di pixel nella griglia del warp (H_w × W_w). È la risoluzione a cui lavora internamente RoMa v2 per questa coppia |
| `raw_matches_above_threshold` | int | Quanti pixel della griglia del warp hanno confidenza ≥ soglia, *prima* del cap `max_keypoints`. Se è molto grande, significa che la coppia ha alta sovrapposizione |
| `filtered_matches` | int | Numero finale di corrispondenze dopo il cap a `max_keypoints`. Questo è il numero di punti che vengono passati alla triangolazione |
| `confidence_threshold` | float | Soglia di confidenza utilizzata per filtrare i match (parametro `--confidence_threshold`) |
| `coverage_ratio` | float [0,1] | Rapporto `raw_matches_above_threshold / total_warp_pixels`. Misura la *frazione dell'immagine* in cui il matcher ha trovato corrispondenze valide. Valori alti (> 0.5) indicano forte sovrapposizione; valori bassi (< 0.1) indicano poca area condivisa o matching difficile |
| `conf_mean` | float [0,1] | Media aritmetica delle confidenze dei match filtrati. Riflette la qualità media del matching. Valori tipici: 0.3–0.6 per coppie wide-baseline, 0.7+ per small-baseline |
| `conf_median` | float [0,1] | Mediana delle confidenze. Meno sensibile agli outlier rispetto alla media — se è molto più bassa della media, ci sono pochi match ad altissima confidenza che alzano la media |
| `conf_std` | float | Deviazione standard delle confidenze. Alta varianza indica matching eterogeneo (alcune zone ottime, altre pessime) |
| `conf_min`, `conf_max` | float | Estremi della distribuzione. `conf_min` è uguale alla soglia se non c'è stato subsampling |
| `conf_p25`, `conf_p75` | float | 25° e 75° percentile. L'intervallo interquartile (p75 – p25) misura la dispersione centrale della distribuzione di confidenza |
| `conf_p90`, `conf_p95`, `conf_p99` | float | Percentili alti. Indicano la qualità dei match migliori. Se p90 > 0.8, almeno il 10% dei match è molto affidabile |
| `conf_bin_00_10` … `conf_bin_90_100` | float [0,1] | Frazioni di match in 6 intervalli di confidenza (0–0.1, 0.1–0.3, 0.3–0.5, 0.5–0.7, 0.7–0.9, 0.9–1.0). Utile per capire la forma della distribuzione senza guardare l'istogramma |
| `spatial_entropy` | float [0, ~6] | Entropia di Shannon della distribuzione spaziale dei keypoint su una griglia 8×8 sull'immagine A. Valore massimo ≈ 6.0 (log₂64, distribuzione perfettamente uniforme). Valori bassi (< 3) indicano match concentrati in poche zone; valori alti (> 5) indicano buona copertura spaziale. L'entropia spaziale è importante perché match concentrati in una piccola area producono triangolazione mal condizionata |
| `warp_smoothness` | float ≥ 0 | Media della magnitudine del gradiente della mappa di confidenza. Valori bassi indicano transizioni graduali di confidenza (matching superficiale liscio); valori alti indicano bordi netti nella confidenza (es. occlusioni, bordi di oggetti). Non è direttamente un indicatore di qualità — dipende dalla scena |
| `inference_time_s` | float | Tempo di inferenza puro del modello RoMa v2 (in secondi). Esclude I/O e post-processing |
| `postprocess_time_s` | float | Tempo di post-processing (filtraggio per soglia, conversione coordinate, cap keypoints) |
| `total_time_s` | float | Somma di `inference_time_s` + `postprocess_time_s` |
| `size_A`, `size_B` | [H, W] | Dimensioni originali (in pixel) delle due immagini |

---

## Report aggregati — Significato

### `roma_pairs_report.csv`

Tabella CSV con una riga per coppia e tutte le colonne sopra descritte. Può essere importato in Excel, Pandas, o qualsiasi tool di analisi. Permette di ordinare e filtrare le coppie per qualsiasi metrica — ad esempio per trovare rapidamente le coppie con la peggior confidenza media, o quelle con la copertura più bassa.

### `roma_summary.json`

Statistiche aggregate calcolate su tutte le coppie processate:

| Campo | Significato |
|-------|-------------|
| `total_pairs` | Numero totale di coppie processate |
| `grand_total_matches` | Somma di tutti i match filtrati di tutte le coppie |
| `avg_matches_per_pair` | Media di match per coppia |
| `zero_match_pairs` | Numero di coppie per cui RoMa v2 non ha prodotto nessun match valido |
| `zero_match_ratio` | Rapporto `zero_match_pairs / total_pairs`. Se è alto, potrebbe indicare soglia troppo aggressiva o coppie con overlap insufficiente |
| `filtered_matches` | Oggetto con `mean`, `median`, `std`, `min`, `max` del numero di match per coppia |
| `coverage_ratio` | Aggregato (mean/median/std/min/max) della copertura |
| `conf_mean` | Aggregato della confidenza media per coppia |
| `conf_median` | Aggregato della mediana di confidenza |
| `spatial_entropy` | Aggregato dell'entropia spaziale |
| `warp_smoothness` | Aggregato della smoothness del warp |
| `inference_time_s` | Aggregato dei tempi di inferenza |
| `total_time_s` | Aggregato dei tempi totali |

### `global_confidence_histogram.png`

Tre istogrammi affiancati che mostrano la distribuzione *tra coppie* di:
- **Confidenza media per coppia** — Come si distribuiscono le coppie in termini di qualità media del matching. Una distribuzione spostata a destra è ideale.
- **Numero di match per coppia** — Distribuzione delle dimensioni del matching. Grandi code a sinistra indicano molte coppie problematiche.
- **Tempo di inferenza per coppia** — Distribuzione dei tempi. Picchi anomali possono indicare immagini particolarmente grandi o complesse.

### `roma_dashboard.html`

Dashboard HTML self-contained che include:
- Riepilogo numerico aggregato (totale coppie, match, zero-match)
- Link al JSON di summary e al CSV
- Visualizzazione dell'istogramma globale
- Tabella interattiva con una riga per coppia, che mostra: numero di match, confidenza media, copertura, entropia spaziale, smoothness del warp, tempo totale
- Per ogni coppia, link diretti a tutti e 6 gli artefatti (heatmap, warp, lines, spatial, histogram, JSON)

Si apre con qualsiasi browser (`open roma_inspection/roma_dashboard.html`).

---

## Parametri CLI completi

| Parametro | Default | Descrizione |
|-----------|---------|-------------|
| `--colmap_dir` | *required* | Directory con cameras.txt, images.txt, points3D.txt |
| `--images_dir` | *required* | Directory con le immagini originali |
| `--output_ply` | `dense_output.ply` | File PLY denso di output |
| `--inspect_dir` | `roma_inspection` | Directory per tutti gli artefatti di ispezione |
| `--no_inspect` | `false` | Se presente, salta la generazione di artefatti (più veloce) |
| `--top_k` | 20 | Partner per immagine nella selezione coppie |
| `--min_shared_points` | 50 | Soglia minima di punti 3D condivisi |
| `--confidence_threshold` | 0.05 | Soglia confidenza RoMa v2 |
| `--max_reproj_error` | 2.0 | Errore di riproiezione max (pixel) |
| `--max_keypoints` | 50000 | Max match densi per coppia |
| `--max_pairs` | 0 (tutti) | Limite coppie da processare |
| `--distance_threshold_eval` | 0 (auto) | Soglia per precision/recall nella valutazione finale |

---

## Prerequisiti

```bash
# PyTorch con CUDA
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

# Dipendenze core
pip install numpy scipy Pillow

# Per gli artefatti visivi (altamente raccomandato)
pip install matplotlib

# Opzionale
pip install open3d
```

> **RoMa v2** viene caricato via `torch.hub` da [`Parskatt/romav2`](https://github.com/Parskatt/romav2).
> Se fallisce, il sistema usa RoMa v1 come fallback.

---

## Struttura dei file sorgente

```
colmap_to_dense_ply/
├── pipeline.py           # Orchestratore principale
├── colmap_parser.py      # Parser COLMAP text files
├── pair_selector.py      # Selezione coppie per covisibilità
├── roma_matcher.py       # Wrapper RoMa v2 (torch.hub) + DenseMatchResult
├── roma_inspector.py     # Generazione artefatti visivi + metriche + dashboard
├── triangulator.py       # DLT triangulation + filtri
├── ply_io.py             # Lettura/scrittura PLY
├── evaluator.py          # Metriche sparse vs dense (Chamfer, coverage, …)
├── requirements.txt
└── README.md
```

---

## Note sulla covarianza predittiva

RoMa v2 predice una matrice di precisione Σ⁻¹ ∈ R^{H×W×2×2} per pixel, che esprime l'incertezza geometrica del match in forma di gaussiana 2D. L'implementazione attuale utilizza solo la confidenza scalare per filtraggio e visualizzazione. Per sfruttare la covarianza completa si può estendere `roma_matcher.py` per estrarre Σ⁻¹ dal modello e usarla per:

1. **Pesare i residui** nella triangolazione (DLT pesato / IRLS)
2. **Reweighting dentro RANSAC** per stima di pose più robusta (come mostrato nella Tabella 10 del paper, +20 punti AUC@1°)
3. **Filtraggio adattivo direzionale** — scartare match con alta incertezza lungo una direzione specifica

---

## Riferimenti

- **RoMa v2**: Edstedt et al., *RoMa v2: Harder Better Faster Denser Feature Matching*, arXiv:2511.15706, 2025
- **COLMAP**: Schönberger & Frahm, *Structure-from-Motion Revisited*, CVPR 2016
