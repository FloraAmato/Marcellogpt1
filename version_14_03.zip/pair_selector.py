"""
pair_selector.py
================
Select the best image pairs for dense matching based on covisibility
computed from the COLMAP reconstruction (shared 3D points).
"""

import heapq
from collections import defaultdict
from itertools import combinations
from typing import Dict, List, Tuple

from colmap_parser import Image


def get_top_pairs(
    images: Dict[int, Image],
    top_k: int = 20,
) -> Dict[str, List[Dict]]:
    """
    Given parsed COLMAP images, compute covisibility (# shared 3D points)
    for all image pairs and return, for each image, the top_k best partners.

    Returns
    -------
    {image_name: [{"matched_image": str, "shared_3d_points": int}, ...]}
    """
    # Build inverted index:  point3d_id  →  [image_ids that see it]
    point_to_images: Dict[int, List[int]] = defaultdict(list)

    for img in images.values():
        for pid in img.point3d_ids:
            if pid != -1:
                point_to_images[int(pid)].append(img.image_id)

    # Covisibility counts
    covisibility: Dict[Tuple[int, int], int] = defaultdict(int)
    for observers in point_to_images.values():
        if len(observers) < 2:
            continue
        for id1, id2 in combinations(set(observers), 2):
            key = (min(id1, id2), max(id1, id2))
            covisibility[key] += 1

    # Per-image match lists
    matches_per_image: Dict[int, List[Tuple[int, int]]] = {
        img_id: [] for img_id in images
    }
    for (id1, id2), weight in covisibility.items():
        matches_per_image[id1].append((id2, weight))
        matches_per_image[id2].append((id1, weight))

    # Build result dict keyed by image name
    results: Dict[str, List[Dict]] = {}
    for img_id, matches in matches_per_image.items():
        best = heapq.nlargest(top_k, matches, key=lambda x: x[1])
        results[images[img_id].name] = [
            {
                "matched_image": images[mid].name,
                "shared_3d_points": w,
            }
            for mid, w in best
        ]
    return results


def unique_pairs_from_top_matches(
    top_matches: Dict[str, List[Dict]],
    min_shared_points: int = 50,
) -> List[Tuple[str, str]]:
    """
    Flatten the per-image top-k lists into a set of unique, unordered
    pairs that exceed a minimum covisibility threshold.
    """
    seen = set()
    pairs: List[Tuple[str, str]] = []
    for img_name, matches in top_matches.items():
        for m in matches:
            partner = m["matched_image"]
            if m["shared_3d_points"] < min_shared_points:
                continue
            key = tuple(sorted([img_name, partner]))
            if key not in seen:
                seen.add(key)
                pairs.append(key)
    return pairs
