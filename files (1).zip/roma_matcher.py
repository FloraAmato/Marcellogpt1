"""
roma_matcher.py
===============
Wrapper around RoMa v2 for dense feature matching.

RoMa v2 outputs:
  - Bidirectional warps   W^{A→B} ∈ R^{H×W×2}
  - Confidence masks      p^{A→B} ∈ [0,1]^{H×W×1}
  - (Optional) Precision  Σ^{-1} ∈ R^{H×W×2×2}

We load the model via torch.hub from the official repository.
"""

import torch
import torch.nn.functional as F
import numpy as np
from pathlib import Path
from PIL import Image as PILImage
from typing import Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class DenseMatchResult:
    """Container for a single pair's dense matching output."""
    kpts_A: np.ndarray          # (N, 2)  pixel coords in image A
    kpts_B: np.ndarray          # (N, 2)  pixel coords in image B
    confidences: np.ndarray     # (N,)    match confidence
    warp_AB: Optional[np.ndarray] = None   # full warp map  (H, W, 2)
    conf_map: Optional[np.ndarray] = None  # full confidence map (H, W)


class RoMaV2Matcher:
    """
    Dense matcher powered by RoMa v2.

    Parameters
    ----------
    device : str
        'cuda' or 'cpu'.
    coarse_res : int
        Resolution fed to the coarse matcher (default 560).
    fine_res : int
        Resolution fed to the refiner   (default 864).
    confidence_threshold : float
        Minimum confidence to keep a correspondence.
    max_keypoints : int
        Cap the number of returned correspondences (sampled by confidence).
    """

    def __init__(
        self,
        device: str = "cuda",
        coarse_res: int = 560,
        fine_res: int = 864,
        confidence_threshold: float = 0.05,
        max_keypoints: int = 50_000,
    ):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.coarse_res = coarse_res
        self.fine_res = fine_res
        self.confidence_threshold = confidence_threshold
        self.max_keypoints = max_keypoints

        print(f"[RoMaV2] Loading model on {self.device} …")
        self.model = self._load_model()
        print("[RoMaV2] Model ready.")

    # ──────────────────────────────────────────
    def _load_model(self):
        """Try loading RoMa v2 via torch.hub; fall back to RoMa v1."""
        try:
            model = torch.hub.load(
                "Parskatt/romav2",
                "romav2",
                trust_repo=True,
            )
            print("[RoMaV2] Loaded RoMa v2 from torch.hub.")
        except Exception as e1:
            print(f"[RoMaV2] Could not load romav2: {e1}")
            print("[RoMaV2] Falling back to RoMa (v1) from torch.hub …")
            try:
                model = torch.hub.load(
                    "Parskatt/RoMa",
                    "roma_outdoor",
                    trust_repo=True,
                )
                print("[RoMaV2] Loaded RoMa v1 (outdoor) from torch.hub.")
            except Exception as e2:
                raise RuntimeError(
                    f"Failed to load any RoMa model.\n"
                    f"  v2 error: {e1}\n"
                    f"  v1 error: {e2}\n"
                    "Make sure you have internet access and PyTorch ≥ 2.0."
                )
        model = model.to(self.device).eval()
        return model

    # ──────────────────────────────────────────
    def _load_image(self, path: str) -> torch.Tensor:
        """Load and preprocess an image → (1, 3, H, W) float32 tensor [0,1]."""
        img = PILImage.open(path).convert("RGB")
        tensor = torch.from_numpy(np.array(img)).permute(2, 0, 1).float() / 255.0
        return tensor.unsqueeze(0).to(self.device)

    # ──────────────────────────────────────────
    def match_pair(
        self,
        image_path_A: str,
        image_path_B: str,
    ) -> DenseMatchResult:
        """
        Run dense matching on a pair of images.

        Returns a DenseMatchResult with pixel-coordinate keypoints in
        the *original* image resolution.
        """
        img_A = self._load_image(image_path_A)
        img_B = self._load_image(image_path_B)
        H_A, W_A = img_A.shape[2], img_A.shape[3]
        H_B, W_B = img_B.shape[2], img_B.shape[3]

        with torch.no_grad():
            # RoMa's match() returns dense warp + certainty at the
            # requested resolution, then we sample keypoints.
            warp, certainty = self.model.match(
                image_path_A,
                image_path_B,
                device=self.device,
            )
            # warp: (H, W, 4)  — first 2 channels = normalised coords in A,
            #                     last 2 = normalised coords in B
            # certainty: (H, W)

        # Extract matches above confidence threshold
        conf_flat = certainty.reshape(-1).cpu().numpy()
        warp_flat = warp.reshape(-1, 4).cpu().numpy()

        mask = conf_flat >= self.confidence_threshold
        good_conf = conf_flat[mask]
        good_warp = warp_flat[mask]

        if len(good_conf) == 0:
            return DenseMatchResult(
                kpts_A=np.empty((0, 2)),
                kpts_B=np.empty((0, 2)),
                confidences=np.empty(0),
            )

        # Sub-sample if too many
        if len(good_conf) > self.max_keypoints:
            indices = np.argsort(good_conf)[-self.max_keypoints:]
            good_conf = good_conf[indices]
            good_warp = good_warp[indices]

        # Warp is in normalised coords [-1, 1] → convert to pixels
        kpts_A = np.stack([
            (good_warp[:, 0] + 1) / 2 * W_A,
            (good_warp[:, 1] + 1) / 2 * H_A,
        ], axis=1)

        kpts_B = np.stack([
            (good_warp[:, 2] + 1) / 2 * W_B,
            (good_warp[:, 3] + 1) / 2 * H_B,
        ], axis=1)

        return DenseMatchResult(
            kpts_A=kpts_A,
            kpts_B=kpts_B,
            confidences=good_conf,
            warp_AB=warp.cpu().numpy(),
            conf_map=certainty.cpu().numpy(),
        )
