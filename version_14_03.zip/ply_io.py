"""
ply_io.py
=========
Lightweight PLY read/write for XYZ-RGB point clouds.
Works without external dependencies; optionally uses Open3D if available.
"""

import numpy as np
from pathlib import Path
from typing import Tuple


# ──────────────────────────────────────────────
# Write
# ──────────────────────────────────────────────

def write_ply(
    filepath: str,
    xyz: np.ndarray,
    rgb: np.ndarray,
) -> None:
    """
    Write an XYZ-RGB point cloud as a binary-little-endian PLY.

    Parameters
    ----------
    filepath : output .ply path
    xyz : (N, 3) float64 or float32
    rgb : (N, 3) uint8
    """
    N = xyz.shape[0]
    assert rgb.shape[0] == N

    xyz = np.ascontiguousarray(xyz, dtype=np.float32)
    rgb = np.ascontiguousarray(rgb, dtype=np.uint8)

    header = (
        "ply\n"
        "format binary_little_endian 1.0\n"
        f"element vertex {N}\n"
        "property float x\n"
        "property float y\n"
        "property float z\n"
        "property uchar red\n"
        "property uchar green\n"
        "property uchar blue\n"
        "end_header\n"
    )

    # Pack each vertex as (float32×3, uint8×3) = 15 bytes
    dt = np.dtype([
        ("x", "<f4"), ("y", "<f4"), ("z", "<f4"),
        ("r", "u1"), ("g", "u1"), ("b", "u1"),
    ])
    arr = np.empty(N, dtype=dt)
    arr["x"] = xyz[:, 0]
    arr["y"] = xyz[:, 1]
    arr["z"] = xyz[:, 2]
    arr["r"] = rgb[:, 0]
    arr["g"] = rgb[:, 1]
    arr["b"] = rgb[:, 2]

    with open(filepath, "wb") as f:
        f.write(header.encode("ascii"))
        f.write(arr.tobytes())

    print(f"[PLY] Wrote {N:,} points → {filepath}")


# ──────────────────────────────────────────────
# Read
# ──────────────────────────────────────────────

def read_ply(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Read an XYZ-RGB PLY file (ASCII or binary_little_endian).

    Returns (xyz, rgb) with shapes (N, 3).
    """
    try:
        import open3d as o3d
        pcd = o3d.io.read_point_cloud(str(filepath))
        xyz = np.asarray(pcd.points, dtype=np.float64)
        rgb = (np.asarray(pcd.colors) * 255).astype(np.uint8) if pcd.has_colors() else np.zeros((len(xyz), 3), dtype=np.uint8)
        return xyz, rgb
    except ImportError:
        pass

    # Fallback: simple ASCII reader
    return _read_ply_ascii(filepath)


def _read_ply_ascii(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """Minimal ASCII PLY parser."""
    with open(filepath, "r") as f:
        line = f.readline().strip()
        assert line == "ply", f"Not a PLY file: {filepath}"
        n_vertices = 0
        while True:
            line = f.readline().strip()
            if line.startswith("element vertex"):
                n_vertices = int(line.split()[-1])
            if line == "end_header":
                break

        xyz = np.empty((n_vertices, 3), dtype=np.float64)
        rgb = np.zeros((n_vertices, 3), dtype=np.uint8)
        for i in range(n_vertices):
            parts = f.readline().strip().split()
            xyz[i] = [float(parts[0]), float(parts[1]), float(parts[2])]
            if len(parts) >= 6:
                rgb[i] = [int(parts[3]), int(parts[4]), int(parts[5])]
    return xyz, rgb


# ──────────────────────────────────────────────
# COLMAP points3D.txt → PLY
# ──────────────────────────────────────────────

def colmap_points3d_to_ply(points3d_dict: dict, out_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Convert a parsed COLMAP points3D dictionary to a PLY file and return arrays.
    """
    N = len(points3d_dict)
    xyz = np.empty((N, 3), dtype=np.float64)
    rgb = np.empty((N, 3), dtype=np.uint8)
    for i, pt in enumerate(points3d_dict.values()):
        xyz[i] = pt.xyz
        rgb[i] = pt.rgb

    write_ply(out_path, xyz, rgb)
    return xyz, rgb
