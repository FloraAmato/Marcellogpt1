"""
roma_inspector.py
=================
Generates a complete inspectable output for every RoMa v2 matching step:

  Per-pair visual artifacts:
    - confidence_heatmap.png       Confidence map overlaid on image A
    - warp_colormap.png            Warp visualised as RGB colour transfer
    - match_lines.png              Side-by-side images with sampled match lines
    - confidence_histogram.png     Per-pair confidence distribution
    - spatial_distribution.png     Match locations on image A, coloured by conf

  Per-pair numeric metrics  →  pair_metrics.json
  Aggregate CSV             →  roma_pairs_report.csv
  Aggregate summary         →  roma_summary.json
  Global confidence hist    →  global_confidence_histogram.png
  HTML dashboard            →  roma_dashboard.html
"""

import csv
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from PIL import Image as PILImage, ImageDraw, ImageFont

from roma_matcher import DenseMatchResult

# ─── Try to import matplotlib for plotting; degrade gracefully ───
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    HAS_MPL = True
except ImportError:
    HAS_MPL = False


# ══════════════════════════════════════════════════════════════════
#  PER-PAIR METRICS
# ══════════════════════════════════════════════════════════════════

def compute_pair_metrics(result: DenseMatchResult) -> Dict:
    """
    Compute an exhaustive set of numeric metrics from a single-pair
    DenseMatchResult.  All values are JSON-serialisable.
    """
    c = result.confidences
    n = len(c)
    m: Dict = {}

    # ── Identity ──
    m["image_A"] = result.image_name_A
    m["image_B"] = result.image_name_B

    # ── Counts ──
    m["total_warp_pixels"] = result.total_pixels
    m["raw_matches_above_threshold"] = result.raw_matches_above_thresh
    m["filtered_matches"] = n
    m["confidence_threshold"] = result.confidence_threshold_used

    # ── Coverage ratio ──
    #   Fraction of warp-grid pixels with conf ≥ threshold.
    #   High value → the two images share a lot of visible scene.
    m["coverage_ratio"] = (
        result.raw_matches_above_thresh / max(result.total_pixels, 1)
    )

    # ── Confidence statistics ──
    if n > 0:
        m["conf_mean"]   = float(np.mean(c))
        m["conf_median"] = float(np.median(c))
        m["conf_std"]    = float(np.std(c))
        m["conf_min"]    = float(np.min(c))
        m["conf_max"]    = float(np.max(c))
        m["conf_p25"]    = float(np.percentile(c, 25))
        m["conf_p75"]    = float(np.percentile(c, 75))
        m["conf_p90"]    = float(np.percentile(c, 90))
        m["conf_p95"]    = float(np.percentile(c, 95))
        m["conf_p99"]    = float(np.percentile(c, 99))

        # Confidence bins — fraction in each bracket
        for lo, hi, label in [
            (0.0, 0.1, "conf_bin_00_10"),
            (0.1, 0.3, "conf_bin_10_30"),
            (0.3, 0.5, "conf_bin_30_50"),
            (0.5, 0.7, "conf_bin_50_70"),
            (0.7, 0.9, "conf_bin_70_90"),
            (0.9, 1.01, "conf_bin_90_100"),
        ]:
            m[label] = float(((c >= lo) & (c < hi)).sum() / n)
    else:
        for k in ("conf_mean", "conf_median", "conf_std", "conf_min",
                   "conf_max", "conf_p25", "conf_p75", "conf_p90",
                   "conf_p95", "conf_p99"):
            m[k] = None

    # ── Spatial entropy ──
    #   Measures how uniformly matches are spread across image A.
    #   We bin keypoint locations into an 8×8 grid and compute Shannon
    #   entropy of the resulting histogram.  Max entropy = log2(64) ≈ 6.
    m["spatial_entropy"] = _spatial_entropy(result.kpts_A, result.size_A, grid=8)

    # ── Warp smoothness ──
    #   Mean gradient magnitude of the confidence map.
    #   Low value → confidence changes slowly (smooth matching surface).
    m["warp_smoothness"] = _warp_smoothness(result.conf_map)

    # ── Timing ──
    m["inference_time_s"]    = round(result.inference_time_s, 4)
    m["postprocess_time_s"]  = round(result.postprocess_time_s, 4)
    m["total_time_s"]        = round(result.inference_time_s + result.postprocess_time_s, 4)

    # ── Image sizes ──
    m["size_A"] = list(result.size_A)
    m["size_B"] = list(result.size_B)

    return m


def _spatial_entropy(kpts: np.ndarray, size: Tuple[int, int], grid: int = 8) -> float:
    """Shannon entropy of keypoint spatial distribution on an NxN grid."""
    if len(kpts) == 0:
        return 0.0
    H, W = size
    bx = np.clip((kpts[:, 0] / max(W, 1) * grid).astype(int), 0, grid - 1)
    by = np.clip((kpts[:, 1] / max(H, 1) * grid).astype(int), 0, grid - 1)
    hist = np.zeros(grid * grid, dtype=np.float64)
    for i in range(len(kpts)):
        hist[by[i] * grid + bx[i]] += 1
    hist = hist / hist.sum()
    hist = hist[hist > 0]
    return float(-np.sum(hist * np.log2(hist)))


def _warp_smoothness(conf_map: Optional[np.ndarray]) -> float:
    """Mean gradient magnitude of the confidence map."""
    if conf_map is None or conf_map.size == 0:
        return 0.0
    gy = np.diff(conf_map, axis=0)
    gx = np.diff(conf_map, axis=1)
    # Crop to matching shapes
    h = min(gy.shape[0], gx.shape[0])
    w = min(gy.shape[1], gx.shape[1])
    mag = np.sqrt(gy[:h, :w] ** 2 + gx[:h, :w] ** 2)
    return float(mag.mean())


# ══════════════════════════════════════════════════════════════════
#  PER-PAIR VISUAL ARTIFACTS
# ══════════════════════════════════════════════════════════════════

def generate_pair_artifacts(
    result: DenseMatchResult,
    image_path_A: str,
    image_path_B: str,
    out_dir: str,
    pair_metrics: Optional[Dict] = None,
    max_lines: int = 300,
) -> Dict[str, str]:
    """
    Generate all visual artifacts for one pair.

    Returns a dict mapping artifact name → file path.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    imgA = PILImage.open(image_path_A).convert("RGB")
    imgB = PILImage.open(image_path_B).convert("RGB")
    imgA_np = np.array(imgA)
    imgB_np = np.array(imgB)

    files: Dict[str, str] = {}

    # ── 1. Confidence heatmap ─────────────────────────────
    path = str(out / "confidence_heatmap.png")
    _draw_confidence_heatmap(result.conf_map, imgA_np, path)
    files["confidence_heatmap"] = path

    # ── 2. Warp colour transfer ───────────────────────────
    path = str(out / "warp_colormap.png")
    _draw_warp_colormap(result.warp_AB, result.conf_map, imgB_np, path)
    files["warp_colormap"] = path

    # ── 3. Match lines (side by side) ─────────────────────
    path = str(out / "match_lines.png")
    _draw_match_lines(result, imgA, imgB, path, max_lines=max_lines)
    files["match_lines"] = path

    # ── 4. Confidence histogram ───────────────────────────
    if HAS_MPL:
        path = str(out / "confidence_histogram.png")
        _draw_confidence_histogram(result, path)
        files["confidence_histogram"] = path

    # ── 5. Spatial distribution ───────────────────────────
    path = str(out / "spatial_distribution.png")
    _draw_spatial_distribution(result, imgA, path)
    files["spatial_distribution"] = path

    # ── 6. Per-pair metrics JSON ──────────────────────────
    if pair_metrics is None:
        pair_metrics = compute_pair_metrics(result)
    path = str(out / "pair_metrics.json")
    with open(path, "w") as f:
        json.dump(pair_metrics, f, indent=2)
    files["pair_metrics"] = path

    return files


# ── drawing helpers ──────────────────────────────────────

def _draw_confidence_heatmap(
    conf_map: Optional[np.ndarray],
    imgA_np: np.ndarray,
    out_path: str,
):
    """Overlay the confidence map as a semi-transparent heatmap on image A."""
    if conf_map is None:
        return
    H, W = imgA_np.shape[:2]
    # Resize conf_map to image size
    conf_resized = np.array(
        PILImage.fromarray((conf_map * 255).astype(np.uint8)).resize((W, H), PILImage.BILINEAR)
    ).astype(np.float32) / 255.0

    if HAS_MPL:
        fig, ax = plt.subplots(1, 1, figsize=(W / 100, H / 100), dpi=100)
        ax.imshow(imgA_np)
        im = ax.imshow(conf_resized, cmap="inferno", alpha=0.55, vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, fraction=0.03, pad=0.02, label="Confidence")
        ax.set_title("RoMa v2 — Confidence Heatmap", fontsize=9)
        ax.axis("off")
        fig.tight_layout(pad=0.5)
        fig.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    else:
        # Fallback: simple blend
        heatmap = _apply_colormap(conf_resized)
        blended = (0.5 * imgA_np.astype(np.float32) + 0.5 * heatmap).astype(np.uint8)
        PILImage.fromarray(blended).save(out_path)


def _draw_warp_colormap(
    warp_AB: Optional[np.ndarray],
    conf_map: Optional[np.ndarray],
    imgB_np: np.ndarray,
    out_path: str,
):
    """
    Warp colour transfer: for each pixel in A, sample the RGB value from
    the location it maps to in image B.  Dims are modulated by confidence.
    Reproduces the visualisation in RoMa v2 paper Figure 2.
    """
    if warp_AB is None or conf_map is None:
        return
    H_w, W_w = conf_map.shape[:2]
    H_B, W_B = imgB_np.shape[:2]

    # Warp channels 2,3 → normalised coords in B
    warp_b_x = (warp_AB[:, :, 2] + 1) / 2 * W_B   # (H_w, W_w)
    warp_b_y = (warp_AB[:, :, 3] + 1) / 2 * H_B

    ix = np.clip(np.round(warp_b_x).astype(int), 0, W_B - 1)
    iy = np.clip(np.round(warp_b_y).astype(int), 0, H_B - 1)

    sampled = imgB_np[iy, ix].astype(np.float32)          # (H_w, W_w, 3)
    # Modulate brightness by confidence (low conf → dimmer)
    alpha = conf_map[:, :, np.newaxis]                      # (H_w, W_w, 1)
    # Paper uses "brighter = lower confidence" but more intuitive:
    # full colour at high conf, faded at low conf
    result = (sampled * alpha + 40 * (1 - alpha)).astype(np.uint8)

    PILImage.fromarray(result).save(out_path)


def _draw_match_lines(
    result: DenseMatchResult,
    imgA: PILImage.Image,
    imgB: PILImage.Image,
    out_path: str,
    max_lines: int = 300,
):
    """Side-by-side image pair with coloured lines connecting matched points."""
    wA, hA = imgA.size
    wB, hB = imgB.size
    gap = 20
    canvas_w = wA + gap + wB
    canvas_h = max(hA, hB)
    canvas = PILImage.new("RGB", (canvas_w, canvas_h), (30, 30, 30))
    canvas.paste(imgA, (0, 0))
    canvas.paste(imgB, (wA + gap, 0))
    draw = ImageDraw.Draw(canvas)

    n = len(result.confidences)
    if n == 0:
        canvas.save(out_path)
        return

    # Sample up to max_lines, biased towards high confidence
    if n > max_lines:
        rng = np.random.default_rng(42)
        probs = result.confidences / result.confidences.sum()
        idx = rng.choice(n, size=max_lines, replace=False, p=probs)
    else:
        idx = np.arange(n)

    cmin, cmax = result.confidences[idx].min(), result.confidences[idx].max()

    for i in idx:
        x1, y1 = result.kpts_A[i]
        x2, y2 = result.kpts_B[i]
        x2_canvas = x2 + wA + gap
        # Colour: red (low conf) → green (high conf)
        t = (result.confidences[i] - cmin) / max(cmax - cmin, 1e-8)
        r = int(255 * (1 - t))
        g = int(255 * t)
        draw.line([(x1, y1), (x2_canvas, y2)], fill=(r, g, 60), width=1)

    # Scale down if huge
    if canvas_w > 3000:
        ratio = 3000 / canvas_w
        canvas = canvas.resize((int(canvas_w * ratio), int(canvas_h * ratio)),
                               PILImage.LANCZOS)
    canvas.save(out_path, quality=90)


def _draw_confidence_histogram(result: DenseMatchResult, out_path: str):
    """Histogram of per-match confidence values with key percentiles."""
    if not HAS_MPL:
        return
    c = result.confidences
    fig, ax = plt.subplots(figsize=(6, 3.5))
    ax.hist(c, bins=100, range=(0, 1), color="#4C72B0", edgecolor="white",
            linewidth=0.3, alpha=0.85)
    # Percentile lines
    if len(c) > 0:
        for pct, ls in [(50, "--"), (90, ":"), (95, "-.")]:
            val = np.percentile(c, pct)
            ax.axvline(val, color="crimson", linestyle=ls, linewidth=1,
                       label=f"P{pct} = {val:.3f}")
    ax.set_xlabel("Confidence")
    ax.set_ylabel("Count")
    ax.set_title(f"Confidence distribution — {result.image_name_A} ↔ {result.image_name_B}",
                 fontsize=9)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def _draw_spatial_distribution(
    result: DenseMatchResult,
    imgA: PILImage.Image,
    out_path: str,
):
    """Scatter plot of match locations on image A, coloured by confidence."""
    if len(result.kpts_A) == 0:
        imgA.save(out_path)
        return

    if HAS_MPL:
        fig, ax = plt.subplots(figsize=(imgA.width / 100, imgA.height / 100), dpi=100)
        ax.imshow(np.array(imgA))
        n = len(result.kpts_A)
        # Subsample for readability
        step = max(1, n // 5000)
        idx = np.arange(0, n, step)
        sc = ax.scatter(
            result.kpts_A[idx, 0], result.kpts_A[idx, 1],
            c=result.confidences[idx], cmap="plasma", s=0.4,
            vmin=0, vmax=1, alpha=0.6,
        )
        plt.colorbar(sc, ax=ax, fraction=0.03, pad=0.02, label="Confidence")
        ax.set_title("Spatial distribution of matches on Image A", fontsize=9)
        ax.axis("off")
        fig.tight_layout(pad=0.5)
        fig.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    else:
        # Fallback: draw dots on image
        canvas = imgA.copy()
        draw = ImageDraw.Draw(canvas)
        for i in range(0, len(result.kpts_A), max(1, len(result.kpts_A) // 3000)):
            x, y = result.kpts_A[i]
            t = result.confidences[i]
            r, g = int(255 * (1 - t)), int(255 * t)
            draw.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(r, g, 80))
        canvas.save(out_path)


def _apply_colormap(arr: np.ndarray) -> np.ndarray:
    """Quick inferno-style colourmap without matplotlib."""
    # Simple 3-stop gradient: black → orange → yellow
    r = np.clip(arr * 3, 0, 1)
    g = np.clip(arr * 1.5 - 0.3, 0, 1)
    b = np.clip(1 - arr * 3, 0, 1)
    return (np.stack([r, g, b], axis=-1) * 255).astype(np.uint8)


# ══════════════════════════════════════════════════════════════════
#  AGGREGATE REPORTS
# ══════════════════════════════════════════════════════════════════

def generate_aggregate_report(
    all_pair_metrics: List[Dict],
    out_dir: str,
) -> Dict[str, str]:
    """
    Produce aggregate outputs from a list of per-pair metric dicts.
    Returns a dict mapping artifact name → file path.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    files: Dict[str, str] = {}

    # ── 1. CSV report ─────────────────────────
    csv_path = str(out / "roma_pairs_report.csv")
    if all_pair_metrics:
        keys = list(all_pair_metrics[0].keys())
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for row in all_pair_metrics:
                writer.writerow(row)
    files["pairs_csv"] = csv_path

    # ── 2. Aggregate summary JSON ─────────────
    summary = _compute_summary(all_pair_metrics)
    json_path = str(out / "roma_summary.json")
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)
    files["summary_json"] = json_path

    # ── 3. Global confidence histogram ────────
    if HAS_MPL:
        hist_path = str(out / "global_confidence_histogram.png")
        _draw_global_histogram(all_pair_metrics, hist_path)
        files["global_histogram"] = hist_path

    # ── 4. HTML dashboard ─────────────────────
    html_path = str(out / "roma_dashboard.html")
    _build_html_dashboard(all_pair_metrics, out, html_path)
    files["dashboard_html"] = html_path

    return files


def _compute_summary(metrics_list: List[Dict]) -> Dict:
    """Aggregate statistics across all pairs."""
    s: Dict = {}
    n = len(metrics_list)
    s["total_pairs"] = n
    if n == 0:
        return s

    def _agg(key):
        vals = [m[key] for m in metrics_list if m.get(key) is not None]
        if not vals:
            return {}
        arr = np.array(vals, dtype=np.float64)
        return {
            "mean": round(float(arr.mean()), 6),
            "median": round(float(np.median(arr)), 6),
            "std": round(float(arr.std()), 6),
            "min": round(float(arr.min()), 6),
            "max": round(float(arr.max()), 6),
        }

    s["filtered_matches"] = _agg("filtered_matches")
    s["coverage_ratio"] = _agg("coverage_ratio")
    s["conf_mean"] = _agg("conf_mean")
    s["conf_median"] = _agg("conf_median")
    s["spatial_entropy"] = _agg("spatial_entropy")
    s["warp_smoothness"] = _agg("warp_smoothness")
    s["inference_time_s"] = _agg("inference_time_s")
    s["total_time_s"] = _agg("total_time_s")

    total_matches = sum(m.get("filtered_matches", 0) for m in metrics_list)
    s["grand_total_matches"] = total_matches
    s["avg_matches_per_pair"] = round(total_matches / n, 1)

    # Pairs with zero matches
    zero_pairs = sum(1 for m in metrics_list if m.get("filtered_matches", 0) == 0)
    s["zero_match_pairs"] = zero_pairs
    s["zero_match_ratio"] = round(zero_pairs / n, 4)

    return s


def _draw_global_histogram(metrics_list: List[Dict], out_path: str):
    """Histogram of mean confidence across all pairs."""
    if not HAS_MPL:
        return
    vals = [m["conf_mean"] for m in metrics_list if m.get("conf_mean") is not None]
    if not vals:
        return
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    # a) Mean confidence per pair
    axes[0].hist(vals, bins=40, color="#55A868", edgecolor="white", linewidth=0.5)
    axes[0].set_xlabel("Mean confidence per pair")
    axes[0].set_ylabel("# pairs")
    axes[0].set_title("Distribution of pair-level mean confidence")

    # b) Matches per pair
    matches = [m.get("filtered_matches", 0) for m in metrics_list]
    axes[1].hist(matches, bins=40, color="#C44E52", edgecolor="white", linewidth=0.5)
    axes[1].set_xlabel("Filtered matches per pair")
    axes[1].set_ylabel("# pairs")
    axes[1].set_title("Distribution of match counts")

    # c) Inference time per pair
    times = [m.get("inference_time_s", 0) for m in metrics_list]
    axes[2].hist(times, bins=40, color="#4C72B0", edgecolor="white", linewidth=0.5)
    axes[2].set_xlabel("Inference time (s)")
    axes[2].set_ylabel("# pairs")
    axes[2].set_title("Distribution of inference time")

    fig.suptitle("RoMa v2 — Aggregate Matching Statistics", fontsize=11, y=1.02)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def _build_html_dashboard(
    metrics_list: List[Dict],
    artifacts_root: Path,
    out_path: str,
):
    """Build a self-contained HTML dashboard linking to all per-pair artifacts."""
    rows_html = []
    for i, m in enumerate(metrics_list):
        pair_slug = f"{_slug(m['image_A'])}__{_slug(m['image_B'])}"
        pair_dir = f"pairs/{pair_slug}"
        n_matches = m.get("filtered_matches", 0)
        cm = m.get("conf_mean")
        cm_str = f"{cm:.4f}" if cm is not None else "—"
        cov = m.get("coverage_ratio", 0)
        se = m.get("spatial_entropy", 0)
        ws = m.get("warp_smoothness", 0)
        t = m.get("total_time_s", 0)

        rows_html.append(f"""
        <tr>
          <td>{i+1}</td>
          <td><code>{m['image_A']}</code></td>
          <td><code>{m['image_B']}</code></td>
          <td class="num">{n_matches:,}</td>
          <td class="num">{cm_str}</td>
          <td class="num">{cov:.4f}</td>
          <td class="num">{se:.3f}</td>
          <td class="num">{ws:.5f}</td>
          <td class="num">{t:.3f}s</td>
          <td>
            <a href="{pair_dir}/confidence_heatmap.png" target="_blank">heatmap</a> ·
            <a href="{pair_dir}/warp_colormap.png" target="_blank">warp</a> ·
            <a href="{pair_dir}/match_lines.png" target="_blank">lines</a> ·
            <a href="{pair_dir}/spatial_distribution.png" target="_blank">spatial</a> ·
            <a href="{pair_dir}/confidence_histogram.png" target="_blank">hist</a> ·
            <a href="{pair_dir}/pair_metrics.json" target="_blank">json</a>
          </td>
        </tr>""")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>RoMa v2 — Matching Inspection Dashboard</title>
<style>
  body {{ font-family: 'Segoe UI', system-ui, sans-serif; margin: 2em; background: #fafafa; }}
  h1 {{ color: #222; }}
  table {{ border-collapse: collapse; width: 100%; font-size: 13px; }}
  th, td {{ border: 1px solid #ddd; padding: 6px 10px; text-align: left; }}
  th {{ background: #34495e; color: white; position: sticky; top: 0; }}
  tr:nth-child(even) {{ background: #f0f4f8; }}
  .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
  a {{ color: #2980b9; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .summary {{ background: #fff; border: 1px solid #ddd; border-radius: 6px;
              padding: 1em 1.5em; margin-bottom: 1.5em; display: inline-block; }}
  .summary h2 {{ margin-top: 0; }}
  .summary dt {{ font-weight: 600; float: left; width: 260px; }}
  .summary dd {{ margin-left: 280px; }}
  .agg-images {{ margin: 1em 0; }}
  .agg-images img {{ max-width: 100%; border: 1px solid #ccc; border-radius: 4px; }}
  code {{ background: #eee; padding: 1px 4px; border-radius: 3px; font-size: 12px; }}
</style>
</head>
<body>
<h1>RoMa v2 — Matching Inspection Dashboard</h1>

<div class="summary">
  <h2>Aggregate Summary</h2>
  <dl>
    <dt>Total pairs processed</dt><dd>{len(metrics_list)}</dd>
    <dt>Grand total matches</dt><dd>{sum(m.get('filtered_matches',0) for m in metrics_list):,}</dd>
    <dt>Avg matches / pair</dt><dd>{sum(m.get('filtered_matches',0) for m in metrics_list)/max(len(metrics_list),1):,.1f}</dd>
    <dt>Pairs with 0 matches</dt><dd>{sum(1 for m in metrics_list if m.get('filtered_matches',0)==0)}</dd>
  </dl>
  <p>
    <a href="roma_summary.json" target="_blank">Full summary JSON</a> ·
    <a href="roma_pairs_report.csv" target="_blank">Per-pair CSV</a>
  </p>
</div>

<div class="agg-images">
  <img src="global_confidence_histogram.png" alt="Global histograms">
</div>

<h2>Per-Pair Details</h2>
<table>
<thead>
<tr>
  <th>#</th><th>Image A</th><th>Image B</th>
  <th>Matches</th><th>Mean Conf</th><th>Coverage</th>
  <th>Spatial Ent.</th><th>Warp Smooth.</th><th>Time</th>
  <th>Artifacts</th>
</tr>
</thead>
<tbody>
{''.join(rows_html)}
</tbody>
</table>

<p style="color:#888; margin-top:2em; font-size:11px;">
  Generated by <code>roma_inspector.py</code> — COLMAP → RoMa v2 dense matching pipeline.
</p>
</body>
</html>"""

    with open(out_path, "w") as f:
        f.write(html)


def _slug(name: str) -> str:
    """Filesystem-safe slug from image filename."""
    return Path(name).stem.replace(" ", "_").replace("/", "_")
