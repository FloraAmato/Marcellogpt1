"""
triangulator.py
===============
Triangulate 2D correspondences into 3D points using the Direct Linear
Transform (DLT) and filter by reprojection error.
"""

import numpy as np
from typing import Tuple, Optional


def triangulate_dlt(
    P1: np.ndarray,
    P2: np.ndarray,
    pts1: np.ndarray,
    pts2: np.ndarray,
) -> np.ndarray:
    """
    Triangulate N point pairs using the DLT (linear least-squares).

    Parameters
    ----------
    P1, P2 : (3, 4) projection matrices for camera 1 and 2.
    pts1, pts2 : (N, 2) pixel coordinates in each image.

    Returns
    -------
    points_3d : (N, 3) world coordinates.
    """
    N = pts1.shape[0]
    points_3d = np.empty((N, 3), dtype=np.float64)

    for i in range(N):
        x1, y1 = pts1[i]
        x2, y2 = pts2[i]

        # Build 4×4 system  A X = 0
        A = np.array([
            x1 * P1[2] - P1[0],
            y1 * P1[2] - P1[1],
            x2 * P2[2] - P2[0],
            y2 * P2[2] - P2[1],
        ])

        # Solve via SVD — last row of V^T
        _, _, Vt = np.linalg.svd(A)
        X = Vt[-1]
        points_3d[i] = X[:3] / X[3]

    return points_3d


def triangulate_dlt_batched(
    P1: np.ndarray,
    P2: np.ndarray,
    pts1: np.ndarray,
    pts2: np.ndarray,
    batch_size: int = 50_000,
) -> np.ndarray:
    """
    Memory-friendly wrapper that processes in batches.
    """
    N = pts1.shape[0]
    if N == 0:
        return np.empty((0, 3), dtype=np.float64)

    results = []
    for start in range(0, N, batch_size):
        end = min(start + batch_size, N)
        results.append(triangulate_dlt(P1, P2, pts1[start:end], pts2[start:end]))
    return np.vstack(results)


def reprojection_error(
    P: np.ndarray,
    pts_2d: np.ndarray,
    pts_3d: np.ndarray,
) -> np.ndarray:
    """
    Compute per-point reprojection error (Euclidean, in pixels).

    Parameters
    ----------
    P : (3, 4)  projection matrix
    pts_2d : (N, 2) observed pixel coords
    pts_3d : (N, 3) triangulated world coords

    Returns
    -------
    errors : (N,) pixel reprojection errors
    """
    N = pts_3d.shape[0]
    X_hom = np.hstack([pts_3d, np.ones((N, 1))])       # (N, 4)
    proj = (P @ X_hom.T).T                              # (N, 3)
    proj_2d = proj[:, :2] / proj[:, 2:3]                # (N, 2)
    return np.linalg.norm(proj_2d - pts_2d, axis=1)


def filter_by_reprojection(
    P1: np.ndarray,
    P2: np.ndarray,
    pts1: np.ndarray,
    pts2: np.ndarray,
    pts_3d: np.ndarray,
    max_reproj_error: float = 2.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Discard triangulated points whose reprojection error in *either*
    view exceeds `max_reproj_error` pixels.

    Returns filtered (pts1, pts2, pts_3d, mask).
    """
    err1 = reprojection_error(P1, pts1, pts_3d)
    err2 = reprojection_error(P2, pts2, pts_3d)
    max_err = np.maximum(err1, err2)
    mask = max_err < max_reproj_error
    return pts1[mask], pts2[mask], pts_3d[mask], mask


def filter_by_cheirality(
    P1: np.ndarray,
    P2: np.ndarray,
    pts_3d: np.ndarray,
) -> np.ndarray:
    """
    Keep only points that are in front of *both* cameras (positive depth).

    Returns boolean mask.
    """
    N = pts_3d.shape[0]
    X_hom = np.hstack([pts_3d, np.ones((N, 1))])

    # Depth in camera 1
    depth1 = (P1[2] @ X_hom.T)
    # Depth in camera 2
    depth2 = (P2[2] @ X_hom.T)

    return (depth1 > 0) & (depth2 > 0)


def colorize_from_image(
    image: np.ndarray,
    pts_2d: np.ndarray,
) -> np.ndarray:
    """
    Sample RGB colour from `image` at `pts_2d` locations (nearest-neighbour).

    Parameters
    ----------
    image : (H, W, 3) uint8
    pts_2d : (N, 2)  (x, y) pixel coordinates

    Returns
    -------
    colors : (N, 3) uint8
    """
    H, W = image.shape[:2]
    x = np.clip(np.round(pts_2d[:, 0]).astype(int), 0, W - 1)
    y = np.clip(np.round(pts_2d[:, 1]).astype(int), 0, H - 1)
    return image[y, x].astype(np.uint8)
